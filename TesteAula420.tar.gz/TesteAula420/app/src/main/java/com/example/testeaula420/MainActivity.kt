package com.example.testeaula420

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    private lateinit var button1:Button
    private lateinit var button2:Button
    private lateinit var text1:EditText
    private lateinit var text2:EditText


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        button1 = findViewById(R.id.button1)
        button2 = findViewById(R.id.button2)

        text1 = findViewById(R.id.editText1)
        text2 =  findViewById(R.id.textInput1)

        button1.setOnClickListener {
            Toast.makeText(
                applicationContext,
                text1.text,
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    fun chamar2(view: View){
        button2.setOnClickListener {
            Toast.makeText(
                applicationContext,
                text2.text,
                Toast.LENGTH_SHORT
            ).show()
        }
    }
}